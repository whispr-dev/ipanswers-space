# ipanswers.space — 1.0.1

A complete self-hosted IP utility and SkeleTrace Suite showcase for lon1.
Copyright © 2026 whispr.dev. Existing brand artwork remains the property of whispr.dev.

## Deploy from Windows

Requirements: PowerShell 7, Windows OpenSSH and tar (already supplied by current Windows),
your working `ssh lon1` alias, sudo access on lon1, and the existing Ubuntu 22.04+ Caddy service.

In PowerShell:

```powershell
Set-Location "$env:USERPROFILE\Downloads"
tar -xzf .\ipanswers-space-1.0.1.tar.gz
Set-Location .\ipanswers
.\Deploy.ps1
```

Enter your server account's sudo password when prompted. The first installation creates an
isolated Python environment and downloads approximately 130 MB of unpacked DB-IP databases.
No Node.js, Docker, API account, subscription, browser geolocation permission or API key is needed.
Python 3.10+ and maxminddb 3.2.0 are used. Only missing Ubuntu python3-venv support is installed.

The installer backs up Caddy and any previous IP Answers units under
`/var/backups/ipanswers/<UTC timestamp>/`. It adds a marked site block for **ipanswers.space**,
validates the complete Caddyfile, health-checks the app and reloads Caddy. If these final steps
fail, it restores the prior configuration and app release. Other domains and services are not edited.
An existing unmanaged ipanswers.space route causes a clear stop before application installation.
Re-running the same deployment replaces the managed block and app release.

## If Caddy is inactive

Run `./Deploy.ps1 -Diagnose` from PowerShell to get a read-only inventory of web listeners,
Caddy/Nginx/Apache service state, recent Caddy startup messages and running container names/ports.
It does not start, stop, enable or modify services or their configuration. The uploaded diagnostic
files are temporary. Send the output to identify the correct existing web stack before deployment.
The normal installer also prints this diagnostic if caddy.service is inactive, then stops before
creating users, releases, databases or changing the web configuration. It never starts a competing
web server. This package still targets a host Caddy systemd installation; an active Nginx/container
setup needs its route adapted using the diagnostic evidence.

## DNS and Cloudflare

Point the **ipanswers.space A record** to lon1's public IPv4 address. Add an AAAA record only if
lon1 actually serves IPv6. Cloudflare proxying is supported; use **Full (strict)** TLS.
Keep Cloudflare **Pseudo IPv4** off (or Add Header), rather than Overwrite Headers.
Do not apply a Cloudflare rule that forces caching of this hostname's HTML or `/api/me` or `/ip`.
The app sends browser/CDN no-store headers, but an explicit edge override can defeat them.
This is the main operational risk: personalized IP responses must never be shared from cache.
No `www` hostname is configured or required.

Caddy overwrites the private client-IP header on every request. It accepts CF-Connecting-IP
only when the immediate connection came from an official Cloudflare IP range; direct connections
use the socket address. Official ranges are refreshed at deployment, with a verified bundled
fallback. The backend listens only on 127.0.0.1:8764. No public app port is opened.

## What visitors get

- Public IPv4 **or** IPv6 used for the current connection, rendered into the initial HTML.
- Approximate city, region and country, when present in DB-IP Lite.
- Routing organisation and ASN, labelled ISP / network. It may differ from the retail ISP.
- The user-agent string sent by the browser, safely escaped.
- Separate copy buttons for IP, IP version, location, ISP/network, ASN and user-agent, plus Copy all, refresh and JSON/plain-text endpoints.
- A responsive 50:50 desktop layout; the suite panel follows the details on phones.
- Actual SkeleTrace and whispr.dev logos, four product summaries, free Community CTA.
- No app cookies, analytics scripts, advertising trackers, third-party fonts or visitor history.

`GET /api/me` returns the current caller's details. `GET /ip` returns only their address.
Neither endpoint accepts an arbitrary address to look up. `GET /healthz` returns HTTP 200
only when both databases can be read. JavaScript is optional for displaying the initial results.
If data is missing, estimates are marked unavailable; addresses are never replaced with sample values.
A VPN/proxy/mobile network may change the visible address and location. This tool does not test
both IP families or perform VPN/DNS leak detection. User agents may be modified or reduced.

## Updates and operations

DB-IP Lite city and ASN data are under CC BY 4.0, permitting commercial use with attribution.
The required attribution link is present in the footer and privacy details.
A systemd timer checks daily around 04:25–06:25 UTC. It downloads each new monthly release once,
validates both databases and atomically activates them; the app picks them up without a restart.
If a download fails, the last working data remains in use. Two releases are retained.
At roughly 70 days old, the UI flags stale data. Databases are memory-mapped for low overhead.
The app has a 256 MB memory limit and bounded request concurrency, suitable for a small utility.

Useful checks, from PowerShell:

```powershell
ssh lon1 'systemctl status ipanswers.service ipanswers-update.timer --no-pager'
ssh lon1 'curl -fsS http://127.0.0.1:8764/healthz'
ssh lon1 'sudo journalctl -u ipanswers.service -u ipanswers-update.service -n 60 --no-pager'
Invoke-RestMethod https://ipanswers.space/api/me
```

Manual database update:

```powershell
ssh -t lon1 'sudo systemctl start ipanswers-update.service'
```

The application suppresses visitor access logs. Existing hosting, firewall or Cloudflare logging
and security settings remain under the operator's control. No collection of precise location occurs.
Cloudflare security features may set their own cookies; the privacy dialog explains this.

## Local development and tests

Windows (Python 3.10+):

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
.\.venv\Scripts\python.exe .\update_data.py --data-dir .\data
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe .\server.py --data-dir .\data
```

Linux:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python update_data.py --data-dir data
.venv/bin/python -m unittest discover -s tests -v
# Optional UI contract check when Node.js is installed:
node tests/test_controls.mjs
.venv/bin/python server.py --data-dir data
```

Open http://127.0.0.1:8764. Local preview correctly reports a loopback address, not a public IP.
Use the installed HTTPS site to verify the actual visitor address and origin/CDN configuration.
`--behind-caddy` is solely for the deployed loopback proxy and must not be used for untrusted direct access.

## Verification performed

12 passing Python tests cover IP parsing, IPv6, reserved addresses, local MMDB failure behavior,
escaping visitor content, malformed forwarding, proxy-header trust, cache controls, static allowlisting,
plain-text output, path traversal rejection and idempotent Caddy block replacement.
Both real October 2026 DB-IP databases were downloaded, opened and used for IPv4 and IPv6 lookups.
Desktop and 390 px mobile layout were inspected in Chrome. Copy, refresh rendering and privacy dialog
were checked with a static QA fixture made from a real lookup. Backend HTTP behavior was tested separately.
The production Caddy site block validated with official Caddy 2.11.7. Live local Caddy-to-app
integration also verified direct-IP handling, simulated trusted Cloudflare handling, overwritten
spoofed headers, local geolocation and no-store responses. Inactive Caddy detection was regression-tested to stop before installation or configuration changes.
Node clipboard contract checks verified all six per-field buttons, refreshed values, Copy all and disabled
unavailable fields. JavaScript and Python syntax checks passed. The installer has not been executed on lon1 from this environment;
its Caddy validation, dependency installation and live-domain checks also run during deployment.

## Sources and branding

- https://skeletrace.com/home/
- https://skeletrace.com/download/
- https://skeletrace.com/works-with/
- https://whispr.dev/products/
- SkeleTrace logo: whisprer-specops/skeletrace, assets/skeletrace-mark.svg
- whispr.dev logo: whispr-dev/website-whispr-dev, whispr-dev-site/site/assets/whispr-logo.svg
- https://db-ip.com/db/download/ip-to-city-lite
- https://db-ip.com/db/download/ip-to-asn-lite
- https://creativecommons.org/licenses/by/4.0/
- https://pypi.org/project/maxminddb/3.2.0/
- https://caddyserver.com/docs/caddyfile/directives/reverse_proxy
- https://www.cloudflare.com/ips-v4
- https://www.cloudflare.com/ips-v6

“OSINT, made easy.” is the existing SkeleTrace tagline. “See the connections. Find the story.”
and the short companion descriptions are campaign copy for this page. The graph artwork is labelled
illustrative; it contains no visitor telemetry. Product availability/prices are not hardcoded.
