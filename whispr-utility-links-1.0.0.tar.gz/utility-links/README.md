# Whispr utility links updater

Version 1.0.0 · © 2026 whispr.dev

One PowerShell runner adds a compact **Other useful tools** section above the existing footer on each of the six utility homepages. It uses **mdconv.site**, the Markdown/diff tool built in this conversation; `msconv.site` in the request was treated as a typo. The publisher credit is **whispr.dev**.

Each homepage gets ordinary HTTPS links to the other five domains, excluding itself:

- fastping.it.com
- dailystonks.org
- ipanswers.space
- isitmeornot.online
- mdconv.site
- whatdoesmyscreen.fit

The section reads: “If you found this site useful, you may also like whispr.dev’s other utility sites:” and uses the existing page's stylesheet. DailyStonks gets a dark variant. No JavaScript, tracking, extra HTTP endpoint or third-party dependency is added.

## Run from Windows

Requires **PowerShell 7+**, Windows OpenSSH (`ssh`, `scp`) and the existing SSH aliases. Remote hosts need Linux, Python **3.10+**, sudo and their existing, functioning HTTPS sites. No local Python, Node, npm or new server package is needed.

Save `whispr-utility-links-1.0.0.tar.gz` in Downloads, then:

```powershell
Set-Location "$env:USERPROFILE\Downloads"
tar -xzf .\whispr-utility-links-1.0.0.tar.gz
Set-Location .\utility-links
.\Update-UtilityLinks.ps1
```

Enter the appropriate server account's sudo password when prompted. The script keeps the SSH session attached to the terminal so prompts remain visible.

It checks `lon1` first. If all six tools are found and verified there, it stops. Otherwise it checks `nyc1` for only the remaining tools. This supports both the latest “same server” description and the earlier deployments, where FastPing and DailyStonks were on NYC1/Caddy and the other four were on LON1/Nginx. It does not change either web server's configuration or make any assumption that Caddy should replace Nginx.

For a single known host, or a different existing SSH alias:

```powershell
.\Update-UtilityLinks.ps1 -SshAliases lon1
```

For both hosts in a chosen order:

```powershell
.\Update-UtilityLinks.ps1 -SshAliases lon1,nyc1
```

Only the fixed six utility domains are eligible. A missing managed site, unexpected file layout, inactive caching service, invalid origin certificate or a mismatched live stylesheet is reported explicitly. The updater does not scan for arbitrary HTML files or guess a replacement root.

## Audit or undo

To inspect the same roots and HTTPS origins without modifying page files:

```powershell
.\Update-UtilityLinks.ps1 -Audit
```

Audit is optional; the ordinary update already performs these checks before writing on each host.

To undo the last recorded change:

```powershell
.\Update-UtilityLinks.ps1 -UndoLast
```

Keep this extracted updater folder, including its generated `reports` directory, for that one-command undo. A no-op rerun or audit does not discard the last undoable change. The server backups also remain available independently.

Undo refuses to overwrite files changed afterward or to restore into a different active release. It can be repeated safely when the files are already original. If a failure occurs on the second host, the first host's successful changes and backup remain recorded and undoable. There is no claim of a single transaction spanning separate SSH hosts.

## What changes on the servers

| Domain | Managed public directory | Cache reload |
| --- | --- | --- |
| fastping.it.com | `/srv/fastping/current/site` | None; static file serving |
| dailystonks.org | `/opt/dailystonks-web/current/public` | None; reads files per request |
| ipanswers.space | `/opt/ipanswers/current/site` | Brief restart of `ipanswers.service` |
| isitmeornot.online | `/opt/isitmeornot/current/site` | Brief restart of `isitmeornot.service` |
| mdconv.site | `/var/www/mdconv.site/current` | None; static file serving |
| whatdoesmyscreen.fit | `/var/www/whatdoesmyscreen.fit/current` | None; static file serving |

Only `index.html` and `style.css` in these active managed roots are patched. The script resolves each root to its current release, preserves existing document content, styles, template tokens, file ownership and permission bits, and makes atomic file replacements. If the two caching services need restarting, their active PIDs must point at the expected release's `server.py` first. Other services, market data, databases, mail, Litehaus, app JavaScript, APIs, Nginx/Caddy configuration, TLS certificates and DNS are not modified.

Each host's update is prepared as a group before page writes. It checks the HTML identity and compares the origin's stylesheet with the on-disk candidate. It backs up original bytes/metadata under:

```text
/var/backups/whispr-utility-links/<UTC timestamp>-<ID>/
```

It writes the scoped CSS block first, then the HTML block; restarts only the two caching services when changed; and verifies that each homepage's local HTTPS origin serves exactly the expected five links and stylesheet. If activation or serving verification fails, the page files written by that invocation are restored on that host and already-restarted caches are restarted against the originals. Concurrent external edits are reported for attention instead of being blindly overwritten.

The HTTPS checks connect to `127.0.0.1:443`, using the actual domain as TLS SNI and Host, with normal certificate verification and cache-busting query parameters. No visitor data is submitted. These are origin checks; they do not prove that a Cloudflare cache or browser cache has refreshed. If a browser shows the old page after success, use Ctrl+F5. Deliberate Cloudflare “cache everything” rules may require purging the affected homepage and `/style.css` from that zone.

The managed markers make updates idempotent: rerunning does not duplicate sections. It is safe to rerun after deploying an older complete site package, which would otherwise replace these live page edits. This updater does not rewrite your old download archives or application repositories.

## Reports and failures

The Windows runner saves per-host JSON reports and a run summary under `utility-links/reports/`. `latest-change.json` records the last undoable update. A successful message is printed only when all six domains have been found and checked across the selected aliases. Missing sites are listed; any already-completed host is preserved in the report.

Each upload uses a unique private `/tmp/whispr-utility-links-<GUID>` directory. It is removed after a successful result is collected. Failed uploads/installations retain the directory for diagnosis and print its location. Per-host backups are root-readable only. There is a per-host lock to prevent this updater from running against itself concurrently; it also checks release pointers and file contents for intervening deployments.

The main deployment risk is **site-layout drift**: if a tool has been moved or rebuilt outside the managed directories above, the updater stops or reports it missing instead of modifying a guessed file. Its origin certificate must also validate locally. Do not disable TLS verification to work around a certificate problem.

## Tests

Included tests cover all six original homepage/style fixtures, five-link correctness and self exclusion, idempotence, BOM/CRLF, preservation of scripts/template tokens, ambiguous markup rejection, cached-service reloads, partial-write failure, complete per-host restoration, refusal to overwrite later edits, audit, missing roots and changed release pointers.

On Linux with Python 3.10+:

```bash
python3 -m unittest discover -s tests -v
```

The Python transaction tests use POSIX permissions/ownership operations and are intended for Linux. Windows can run the runner tests with no real SSH connection:

```powershell
.\tests\Test-Runner.ps1
```

That fixture mocks SSH/SCP only within its test process and creates/removes its own temporary directories. It covers two-host application, a single-host installation, visible server output, repeated no-op runs, audit, undo order, a failed second host and explicit missing-site failure. Run it in a fresh PowerShell process if you have custom functions named `ssh` or `scp` that you want to preserve in your current session:

```powershell
pwsh -NoProfile -File .\tests\Test-Runner.ps1
```

An optional real-Nginx integration check needs Nginx with TLS, OpenSSL and free loopback port 8798:

```bash
python3 tests/nginx_integration.py /usr/sbin/nginx /etc/nginx/mime.types
```

It creates a temporary prefix and test certificate, checks six SNI hosts over real HTTPS, applies and undoes the complete patch, compares restored bytes, and confirms rejection of an invalid TLS hostname. It does not use production system services or files under `/etc`.

Release validation completed: **12 Python tests**, **5 PowerShell runner scenarios on PowerShell 7.6.8**, real six-host Nginx HTTPS apply/verify/undo, and browser inspection of the footer against all six original stylesheets. Actual updates on the user's servers require running the supplied PowerShell command locally.
