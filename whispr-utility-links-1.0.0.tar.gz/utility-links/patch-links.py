#!/usr/bin/env python3
"""Add reciprocal links to the six existing whispr.dev utility homepages.

Python 3.10+ / Linux. No third-party packages. No web-server or TLS edits.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import datetime as dt
import fcntl
import hashlib
from html import escape
from html.parser import HTMLParser
import http.client
import json
import os
from pathlib import Path
import re
import socket
import ssl
import stat
import subprocess
import sys
import tempfile
import time
import uuid

VERSION = '1.0.0'
BACKUPS = Path('/var/backups/whispr-utility-links')
HTML_BEGIN = '<!-- WHISPR UTILITY LINKS v1 BEGIN -->'
HTML_END = '<!-- WHISPR UTILITY LINKS v1 END -->'
CSS_BEGIN = '/* WHISPR UTILITY LINKS v1 BEGIN */'
CSS_END = '/* WHISPR UTILITY LINKS v1 END */'


@dataclass(frozen=True)
class Site:
    domain: str
    root: Path
    title: str
    description: str
    dark: bool = False
    cached_service: str | None = None


SITES = (
    Site('fastping.it.com',Path('/srv/fastping/current/site'),'FastPing','Connection checks & HTTP test endpoints'),
    Site('dailystonks.org',Path('/opt/dailystonks-web/current/public'),'DailyStonks','Market charts & live quotes',True),
    Site('ipanswers.space',Path('/opt/ipanswers/current/site'),'IPAnswers','Your public IP, location estimate & ISP',cached_service='ipanswers.service'),
    Site('isitmeornot.online',Path('/opt/isitmeornot/current/site'),'Is It Me Or Not','Single & bulk website status checks',cached_service='isitmeornot.service'),
    Site('mdconv.site',Path('/var/www/mdconv.site/current'),'MDConv','Live Markdown preview & text comparison'),
    Site('whatdoesmyscreen.fit',Path('/var/www/whatdoesmyscreen.fit/current'),'What Does My Screen Fit','Viewport, pixel ratio & screen details'),
)
BY_DOMAIN = {site.domain:site for site in SITES}

CSS = '''
.whispr-utilities{display:block;clear:both;box-sizing:border-box;width:100%;margin:12px 0 0;background:#f2f5ef;color:#25372c;border-top:1px solid #dce4d9;border-bottom:1px solid #dce4d9;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-align:left}
.whispr-utilities .whispr-utilities__inner{box-sizing:border-box;max-width:1500px;margin:0 auto;padding:23px clamp(20px,4vw,52px) 25px}
.whispr-utilities .whispr-utilities__heading{font-size:16px;font-weight:650;line-height:1.4;letter-spacing:-.25px;color:inherit;margin:0 0 6px;padding:0;border:0}
.whispr-utilities .whispr-utilities__intro{font-size:11px;line-height:1.7;letter-spacing:normal;color:#5b6d60;margin:0 0 14px;padding:0}
.whispr-utilities .whispr-utilities__intro a{color:inherit;text-decoration:underline;text-underline-offset:3px;font-weight:600}
.whispr-utilities .whispr-utilities__list{display:flex;flex-wrap:wrap;gap:8px;list-style:none;margin:0;padding:0}
.whispr-utilities .whispr-utilities__list li{display:block;margin:0;padding:0;min-width:0}
.whispr-utilities .whispr-utilities__link{display:block;box-sizing:border-box;border:1px solid #d5dfd0;border-radius:5px;background:#fbfdf9;color:#314f3a;padding:8px 11px;font:500 11px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:-.15px;text-decoration:none;overflow-wrap:anywhere;max-width:100%}
.whispr-utilities .whispr-utilities__link:hover{background:#e5eedc;border-color:#9daf91;text-decoration:underline;text-underline-offset:3px}
.whispr-utilities a:focus-visible{outline:3px solid #b17b20;outline-offset:3px}
.whispr-utilities.whispr-utilities--dark{background:#111a13;color:#e8f0e1;border-color:#293b2b}
.whispr-utilities--dark .whispr-utilities__intro{color:#a6b79e}
.whispr-utilities--dark .whispr-utilities__link{background:#172318;color:#d1e6bc;border-color:#354a31}
.whispr-utilities--dark .whispr-utilities__link:hover{background:#253a20;border-color:#8aa16e}
@media(max-width:500px){.whispr-utilities .whispr-utilities__inner{padding:20px 20px 22px}.whispr-utilities .whispr-utilities__list{gap:7px}.whispr-utilities .whispr-utilities__link{font-size:10px;padding:7px 9px}.whispr-utilities .whispr-utilities__intro{font-size:10px}}
'''.strip()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def link_block(domain: str) -> str:
    site = BY_DOMAIN[domain]
    theme = ' whispr-utilities--dark' if site.dark else ''
    lines = [HTML_BEGIN,
        f'<section class="whispr-utilities{theme}" data-whispr-utilities="{domain}" aria-labelledby="whispr-utilities-heading">',
        '<div class="whispr-utilities__inner">',
        '<h2 id="whispr-utilities-heading" class="whispr-utilities__heading">Other useful tools.</h2>',
        '<p class="whispr-utilities__intro">If you found this site useful, you may also like <a href="https://whispr.dev/">whispr.dev</a>’s other utility sites:</p>',
        '<ul class="whispr-utilities__list">']
    for other in SITES:
        if other.domain == domain:
            continue
        label = escape(other.title+' — '+other.description,quote=True)
        lines.append(f'<li><a class="whispr-utilities__link" href="https://{other.domain}/" title="{label}" aria-label="{label}">{other.domain} <span aria-hidden="true">↗</span></a></li>')
    lines += ['</ul></div></section>',HTML_END]
    return '\n'.join(lines)


class Document(HTMLParser):
    """Find actual tag offsets, ignoring closing-tag strings inside scripts."""
    def __init__(self,text: str):
        super().__init__(convert_charrefs=False)
        self.text = text
        self.starts = [0]
        for match in re.finditer('\n',text):self.starts.append(match.end())
        self.footers = []; self.body_ends = []; self.head_ends = []
        self.ids = []; self.comments = []; self.links = []; self.styles = []
        self.feed(text);self.close()

    def character_offset(self):
        line,column = self.getpos()
        return self.starts[line-1]+column

    def handle_starttag(self,tag,attrs):
        attributes = dict(attrs)
        if tag == 'footer':self.footers.append(self.character_offset())
        if attributes.get('id'):self.ids.append(attributes['id'])
        if tag == 'a':self.links.append(attributes)
        if tag == 'link' and 'stylesheet' in attributes.get('rel','').split():self.styles.append(attributes.get('href'))

    def handle_endtag(self,tag):
        if tag == 'body':self.body_ends.append(self.character_offset())
        if tag == 'head':self.head_ends.append(self.character_offset())

    def handle_comment(self,data):
        self.comments.append((data.strip(),self.character_offset()))


def patch_html(original: bytes,domain: str) -> bytes:
    text = original.decode('utf-8')
    document = Document(text)
    if len(document.body_ends)!=1 or len(document.head_ends)!=1:
        raise ValueError(domain+': expected a complete HTML document with one head/body.')
    if not any(value in ('/style.css','style.css','./style.css') for value in document.styles):
        raise ValueError(domain+': the existing /style.css link was not found.')
    newline = '\r\n' if '\r\n' in text else '\n'
    begins = [(value,offset) for value,offset in document.comments if value == 'WHISPR UTILITY LINKS v1 BEGIN']
    ends = [(value,offset) for value,offset in document.comments if value == 'WHISPR UTILITY LINKS v1 END']
    block = link_block(domain).replace('\n',newline)
    if begins or ends:
        if len(begins)!=1 or len(ends)!=1 or begins[0][1]>=ends[0][1]:
            raise ValueError(domain+': incomplete or duplicate managed link markers; nothing overwritten.')
        start,end = begins[0][1],ends[0][1]+len(HTML_END)
        if not document.head_ends[0]<start<end<document.body_ends[0]:
            raise ValueError(domain+': managed links are outside the body.')
        text = text[:start]+block+text[end:]
    else:
        if 'whispr-utilities-heading' in document.ids:
            raise ValueError(domain+': an unrelated element already uses the new heading ID.')
        if len(document.footers)>1:
            raise ValueError(domain+': multiple footers need an explicit insertion choice.')
        insert = document.footers[0] if document.footers else document.body_ends[0]
        text = text[:insert]+block+newline+text[insert:]
    result = text.encode('utf-8')
    validate_links(result,domain)
    return result


def patch_css(original: bytes) -> bytes:
    text = original.decode('utf-8')
    newline = '\r\n' if '\r\n' in text else '\n'
    block = (CSS_BEGIN+'\n'+CSS+'\n'+CSS_END).replace('\n',newline)
    if CSS_BEGIN in text or CSS_END in text:
        if text.count(CSS_BEGIN)!=1 or text.count(CSS_END)!=1 or text.index(CSS_BEGIN)>text.index(CSS_END):
            raise ValueError('Incomplete or duplicate CSS markers; nothing overwritten.')
        start,end = text.index(CSS_BEGIN),text.index(CSS_END)+len(CSS_END)
        text = text[:start]+block+text[end:]
    else:
        text += ('' if text.endswith('\n') else newline)+newline+block+newline
    return text.encode('utf-8')


def validate_links(html: bytes,domain: str):
    text = html.decode('utf-8')
    document = Document(text)
    begins = [p for value,p in document.comments if value == 'WHISPR UTILITY LINKS v1 BEGIN']
    ends = [p for value,p in document.comments if value == 'WHISPR UTILITY LINKS v1 END']
    if len(begins)!=1 or len(ends)!=1 or begins[0]>=ends[0]:
        raise ValueError(domain+': the served page does not contain exactly one link section.')
    fragment = Document(text[begins[0]:ends[0]+len(HTML_END)])
    links = [a.get('href') for a in fragment.links if a.get('class') == 'whispr-utilities__link']
    expected = ['https://'+site.domain+'/' for site in SITES if site.domain != domain]
    if links != expected:
        raise ValueError(domain+': the five served links do not match the other utility sites.')


class Origin:
    """HTTPS to local 443, with the site's Host/SNI and normal TLS verification."""
    def __init__(self,context=None,port=443):
        self.context = context or ssl.create_default_context()
        self.port = port

    def fetch(self,domain: str,path: str) -> bytes:
        raw = socket.create_connection(('127.0.0.1',self.port),timeout=8)
        try:secure = self.context.wrap_socket(raw,server_hostname=domain)
        except BaseException:
            raw.close();raise
        connection = http.client.HTTPConnection(domain,timeout=8)
        connection.sock = secure
        separator = '&' if '?' in path else '?'
        target = path+separator+'whispr_links_check='+uuid.uuid4().hex
        try:
            connection.request('GET',target,headers={'Host':domain,'Accept-Encoding':'identity','Cache-Control':'no-cache','User-Agent':'whispr-utility-links/'+VERSION,'Connection':'close'})
            response = connection.getresponse()
            body = response.read(4_000_001)
            if response.status!=200:raise RuntimeError(f'{domain}{path}: origin returned HTTP {response.status}.')
            if len(body)>4_000_000:raise RuntimeError(domain+': unexpectedly large response.')
            if response.getheader('Content-Encoding','identity') not in ('','identity'):
                raise RuntimeError(domain+': origin did not honour identity encoding.')
            return body
        finally:connection.close()


def service_active(name: str) -> bool:
    return subprocess.run(['systemctl','is-active','--quiet',name],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0


def validate_cached_service(site: Site,root: Path):
    if not site.cached_service:return
    if not service_active(site.cached_service):
        raise RuntimeError(site.domain+': '+site.cached_service+' is not active. No pages changed.')
    pid = subprocess.run(['systemctl','show',site.cached_service,'--property=MainPID','--value'],check=True,capture_output=True,text=True).stdout.strip()
    if not pid.isdigit() or int(pid)<=0:raise RuntimeError(site.domain+': service PID could not be verified.')
    arguments = Path('/proc',pid,'cmdline').read_bytes().split(b'\0')
    expected = root.parent/'server.py'
    if not any(value.startswith(b'/') and Path(os.fsdecode(value)).resolve()==expected for value in arguments if value):
        raise RuntimeError(site.domain+': active service does not use this managed release. No pages changed.')


def restart_service(name: str):
    print('Reloading cached page through '+name+' ...',flush=True)
    subprocess.run(['systemctl','restart',name],check=True)
    if not service_active(name):raise RuntimeError(name+' did not become active.')


@dataclass
class Edit:
    site: Site
    root: Path
    path: Path
    before: bytes
    after: bytes
    info: os.stat_result


def plan(selected: list[Site],origin: Origin):
    found = []; missing = []; edits = []
    for site in selected:
        if not site.root.exists():
            missing.append(site.domain)
            print('Not installed in its managed location on this host: '+site.domain,flush=True)
            continue
        root = site.root.resolve(strict=True)
        if not root.is_dir():raise RuntimeError(site.domain+': managed root is not a directory.')
        html_path,css_path = root/'index.html',root/'style.css'
        for path in (html_path,css_path):
            if path.is_symlink() or not path.is_file():raise RuntimeError(str(path)+': expected a regular file.')
        html,css = html_path.read_bytes(),css_path.read_bytes()
        if site.domain not in html.decode('utf-8').lower() and site.title.lower() not in html.decode('utf-8').lower():
            raise RuntimeError(site.domain+': HTML identity does not match this utility.')
        after_html,after_css = patch_html(html,site.domain),patch_css(css)
        validate_cached_service(site,root)
        # Matching the live stylesheet proves the candidate resembles the active release.
        # Final serving checks below also catch an identical old release at another path.
        if origin.fetch(site.domain,'/style.css') != css:
            raise RuntimeError(site.domain+': the active origin stylesheet differs from the managed file. No pages changed.')
        served = origin.fetch(site.domain,'/')
        if site.domain not in served.decode('utf-8').lower() and site.title.lower() not in served.decode('utf-8').lower():
            raise RuntimeError(site.domain+': origin homepage identity does not match. No pages changed.')
        if after_html == html and after_css == css:
            validate_links(served,site.domain)
            print('Already installed and served correctly: '+site.domain,flush=True)
        else:
            # Write CSS first, then markup, to avoid showing an unstyled link block.
            for path,before,after in [(css_path,css,after_css),(html_path,html,after_html)]:
                if before != after:edits.append(Edit(site,root,path,before,after,path.stat()))
            print('Ready to add five links: '+site.domain,flush=True)
        found.append(site)
    return found,missing,edits


def atomic(path: Path,data: bytes,mode: int,uid: int,gid: int):
    fd,name = tempfile.mkstemp(prefix='.'+path.name+'.whispr-links-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.chmod(name,mode);os.chown(name,uid,gid);os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def save_state(folder: Path,state: dict):
    atomic(folder/'state.json',(json.dumps(state,indent=2)+'\n').encode(),0o600,0,0)


def backup(edits: list[Edit]):
    if BACKUPS.is_symlink():raise RuntimeError('Backup base must not be a symlink.')
    BACKUPS.mkdir(mode=0o700,parents=True,exist_ok=True);BACKUPS.chmod(0o700)
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    folder = BACKUPS/stamp;folder.mkdir(mode=0o700)
    state = {'version':1,'id':stamp,'status':'prepared','entries':[]}
    for index,edit in enumerate(edits):
        name = f'{index:03d}.original'
        atomic(folder/name,edit.before,0o600,0,0)
        state['entries'].append({'domain':edit.site.domain,'root':str(edit.root),'path':str(edit.path),'backup':name,'before':digest(edit.before),'after':digest(edit.after),'mode':stat.S_IMODE(edit.info.st_mode),'uid':edit.info.st_uid,'gid':edit.info.st_gid,'atime_ns':edit.info.st_atime_ns,'mtime_ns':edit.info.st_mtime_ns})
    save_state(folder,state)
    return folder,state


def verify_served(origin: Origin,sites: list[Site],expected_css: dict[str,bytes]):
    for site in sites:
        last = None
        for attempt in range(6):
            try:
                validate_links(origin.fetch(site.domain,'/'),site.domain)
                css = origin.fetch(site.domain,'/style.css')
                if css != expected_css[site.domain]:raise RuntimeError(site.domain+': changed stylesheet is not being served.')
                last = None;break
            except (OSError,ValueError,RuntimeError,http.client.HTTPException) as error:
                last = error
                if attempt<5:time.sleep(.5)
        if last:raise last
        print('Verified five links at the local HTTPS origin: '+site.domain,flush=True)


def apply(selected: list[Site],origin: Origin,audit=False):
    sites,missing,edits = plan(selected,origin)
    result = {'ok':True,'version':VERSION,'mode':'audit' if audit else 'apply','sites':[site.domain for site in sites],'missing':missing,'changed':[],'backup':None}
    if audit or not edits:return result
    expected_css = {site.domain:patch_css((site.root/'style.css').read_bytes()) for site in sites}
    folder,state = backup(edits)
    print('Backup: '+str(folder),flush=True)
    written = []; restarted = set()
    try:
        # Validate every source before committing the first file.
        for edit in edits:
            if edit.site.root.resolve()!=edit.root or edit.path.read_bytes()!=edit.before or edit.path.is_symlink():
                raise RuntimeError('The release changed during preparation: '+edit.site.domain)
        for edit in edits:
            if edit.site.root.resolve()!=edit.root or edit.path.read_bytes()!=edit.before or edit.path.is_symlink():
                raise RuntimeError('The release changed during update: '+edit.site.domain)
            atomic(edit.path,edit.after,stat.S_IMODE(edit.info.st_mode),edit.info.st_uid,edit.info.st_gid)
            written.append(edit)
        for name in sorted({edit.site.cached_service for edit in written if edit.site.cached_service}):
            restarted.add(name);restart_service(name)
        for edit in written:
            if edit.site.root.resolve()!=edit.root:raise RuntimeError('The release pointer changed: '+edit.site.domain)
        verify_served(origin,sites,expected_css)
        state['status']='applied';save_state(folder,state)
        result['changed']=sorted({edit.site.domain for edit in written});result['backup']=str(folder)
        return result
    except BaseException as error:
        problems = []
        for edit in reversed(written):
            try:
                if edit.path.is_symlink() or edit.path.read_bytes()!=edit.after:
                    raise RuntimeError('External edits detected; not overwriting '+str(edit.path))
                atomic(edit.path,edit.before,stat.S_IMODE(edit.info.st_mode),edit.info.st_uid,edit.info.st_gid)
                os.utime(edit.path,ns=(edit.info.st_atime_ns,edit.info.st_mtime_ns))
            except Exception as restore_error:problems.append(str(restore_error))
        for name in sorted(restarted):
            try:restart_service(name)
            except Exception as restore_error:problems.append(str(restore_error))
        state['status']='rollback-needs-attention' if problems else 'automatically-restored'
        save_state(folder,state)
        detail = '; '.join(problems) if problems else 'Original page files restored on this host.'
        raise RuntimeError(f'{error} {detail} Backup: {folder}') from error


def rollback(backup_id: str,origin: Origin):
    if not re.fullmatch(r'\d{8}T\d{6}Z-[0-9a-f]{8}',backup_id):raise ValueError('Use the backup ID printed by this updater.')
    folder = BACKUPS/backup_id
    if folder.is_symlink() or not folder.is_dir():raise ValueError('Backup directory not found.')
    state = json.loads((folder/'state.json').read_text())
    if state.get('version')!=1 or state.get('id')!=backup_id:raise ValueError('Unrecognised backup format.')
    records = [];sites = {};seen = set()
    for entry in state['entries']:
        site = BY_DOMAIN[entry['domain']];root = site.root.resolve(strict=True)
        path = Path(entry['path']);name = entry['backup']
        if entry['root']!=str(root) or path.parent!=root or path.name not in ('index.html','style.css') or not re.fullmatch(r'\d{3}\.original',name):
            raise ValueError('The active release changed, or a backup path is invalid. No rollback performed.')
        if path in seen or path.is_symlink():raise ValueError('Duplicate or symlinked backup destination.')
        seen.add(path)
        previous = (folder/name).read_bytes();current = path.read_bytes()
        if digest(previous)!=entry['before']:raise ValueError('Backup checksum does not match.')
        if digest(current) not in (entry['before'],entry['after']):
            raise ValueError('This file was edited after the update; refusing to overwrite it: '+str(path))
        validate_cached_service(site,root)
        records.append((entry,path,previous,current,path.stat()));sites[site.domain]=site
    written = [];restarted = set()
    try:
        for entry,path,previous,current,info in records:
            if previous==current:continue
            if path.read_bytes()!=current or path.is_symlink():raise RuntimeError('File changed during rollback.')
            atomic(path,previous,entry['mode'],entry['uid'],entry['gid']);written.append((entry,path,previous,current,info))
            os.utime(path,ns=(entry['atime_ns'],entry['mtime_ns']))
        for name in sorted({site.cached_service for site in sites.values() if site.cached_service and written}):
            restarted.add(name);restart_service(name)
        for domain,site in sites.items():
            css=origin.fetch(domain,'/style.css')
            if css!=(site.root/'style.css').read_bytes():raise RuntimeError(domain+': restored stylesheet is not served.')
            html=origin.fetch(domain,'/').decode('utf-8')
            original=(site.root/'index.html').read_text()
            if HTML_BEGIN in original:validate_links(html.encode(),domain)
            elif HTML_BEGIN in html:raise RuntimeError(domain+': cached original page was not restored.')
        state['status']='manually-restored';save_state(folder,state)
        return {'ok':True,'mode':'rollback','sites':list(sites),'changed':sorted({entry['domain'] for entry,_,_,_,_ in written}),'backup':str(folder)}
    except BaseException:
        for entry,path,previous,current,info in reversed(written):
            if path.read_bytes()==previous:
                atomic(path,current,stat.S_IMODE(info.st_mode),info.st_uid,info.st_gid)
        for name in sorted(restarted):restart_service(name)
        raise


def write_report(path: Path,result: dict):
    # The runner's new, private upload directory is readable only by its SSH user.
    if path.is_symlink():raise ValueError('Report destination must not be a symlink.')
    atomic(path,(json.dumps(result,indent=2)+'\n').encode(),0o644,0,0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--audit',action='store_true')
    mode.add_argument('--rollback',metavar='BACKUP_ID')
    parser.add_argument('--sites',default=','.join(BY_DOMAIN),help='Comma-separated known domains; others are rejected.')
    parser.add_argument('--report',type=Path)
    args = parser.parse_args()
    status = 0
    try:
        if os.geteuid()!=0:raise RuntimeError('Run using sudo python3 patch-links.py.')
        domains = args.sites.split(',')
        if len(set(domains))!=len(domains) or any(domain not in BY_DOMAIN for domain in domains):
            raise ValueError('Only the six configured utility domains may be selected.')
        with open('/run/lock/whispr-utility-links.lock','w') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise RuntimeError('Another utility-link update is running on this host.')
            origin = Origin()
            result = rollback(args.rollback,origin) if args.rollback else apply([BY_DOMAIN[domain] for domain in domains],origin,args.audit)
    except Exception as error:
        result = {'ok':False,'mode':'rollback' if args.rollback else 'audit' if args.audit else 'apply','error':str(error),'sites':[],'changed':[]}
        print('ERROR: '+str(error),file=sys.stderr,flush=True);status=1
    if args.report:write_report(args.report,result)
    print(json.dumps(result),flush=True)
    return status


if __name__=='__main__':sys.exit(main())
