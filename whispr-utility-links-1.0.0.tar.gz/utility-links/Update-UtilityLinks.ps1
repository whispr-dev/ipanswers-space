#requires -Version 7.0
[CmdletBinding()]
param(
    [string[]]$SshAliases = @('lon1', 'nyc1'),
    [switch]$Audit,
    [switch]$UndoLast
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference = $false
if ($Audit -and $UndoLast) { throw 'Choose -Audit or -UndoLast, not both.' }

$domains = @('fastping.it.com','dailystonks.org','ipanswers.space','isitmeornot.online','mdconv.site','whatdoesmyscreen.fit')
$source = Join-Path $PSScriptRoot 'patch-links.py'
$reports = Join-Path $PSScriptRoot 'reports'
$latest = Join-Path $reports 'latest-change.json'
$runId = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
$runFile = Join-Path $reports ($runId + '.json')

function Assert-Alias([string]$Name) {
    if ($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9_.-]*$') { throw "Use an SSH alias such as lon1 or nyc1: $Name" }
}
function Invoke-Checked([string]$Executable, [string[]]$Arguments) {
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Executable failed with exit code $LASTEXITCODE. Read the output above." }
}
function Save-Run($Value, [string]$Path) {
    $json = ConvertTo-Json -InputObject $Value -Depth 12
    $temporary = $Path + '.tmp'
    [IO.File]::WriteAllText($temporary, $json, [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}
function Invoke-HostUpdate([string]$Alias, [string[]]$Selected, [ref]$OutputRecord, [string]$BackupId = '') {
    Assert-Alias $Alias
    $remote = '/tmp/whispr-utility-links-' + [guid]::NewGuid().ToString('N')
    $localReport = Join-Path $reports ($runId + '-' + $Alias + '-' + [guid]::NewGuid().ToString('N').Substring(0,6) + '.json')
    Write-Host "`nChecking utility sites through '$Alias'..." -ForegroundColor Cyan
    Invoke-Checked 'ssh' @('-o','ConnectTimeout=15','-o','ConnectionAttempts=1',$Alias,"umask 077; mkdir '$remote'")
    Invoke-Checked 'scp' @('-o','ConnectTimeout=15',$source,"${Alias}:$remote/patch-links.py")
    if ($BackupId) {
        if ($BackupId -notmatch '^\d{8}T\d{6}Z-[0-9a-f]{8}$') { throw 'Invalid backup ID in the saved report.' }
        $arguments = "--rollback '$BackupId'"
    } else {
        if (@($Selected | Where-Object { $_ -notin $domains }).Count) { throw 'Unexpected utility domain.' }
        $arguments = "--sites '$($Selected -join ',')'"
        if ($Audit) { $arguments += ' --audit' }
    }
    Write-Host 'Enter this server account''s sudo password if prompted.'
    # Keep SSH output attached to the terminal so sudo prompts remain visible.
    & ssh -t -o ServerAliveInterval=15 -o ServerAliveCountMax=3 $Alias "sudo -- python3 '$remote/patch-links.py' $arguments --report '$remote/report.json'"
    $serverExit = $LASTEXITCODE
    & scp -o ConnectTimeout=15 "${Alias}:$remote/report.json" $localReport
    $reportExit = $LASTEXITCODE
    if ($reportExit -ne 0 -or -not (Test-Path -LiteralPath $localReport)) {
        throw "Could not collect the server result. Uploaded files remain on ${Alias}:$remote. Nothing is being reported as complete."
    }
    $result = Get-Content -LiteralPath $localReport -Raw | ConvertFrom-Json
    if ($serverExit -ne 0 -or -not $result.ok) {
        $detail = if ($result.PSObject.Properties.Name -contains 'error') { [string]$result.error } else { 'The SSH session did not report success.' }
        throw "Update failed on ${Alias}: $detail Installer retained at $remote; report: $localReport"
    }
    & ssh -o ConnectTimeout=15 $Alias "rm -rf -- '$remote'"
    if ($LASTEXITCODE -ne 0) { Write-Warning "Update succeeded, but the temporary upload directory could not be removed: ${Alias}:$remote" }
    $OutputRecord.Value = [pscustomobject]@{ ssh_alias=$Alias; result=$result; local_report=$localReport }
}

foreach ($command in @('ssh','scp')) {
    if (-not (Get-Command $command -ErrorAction SilentlyContinue)) { throw "Required tool missing: $command" }
}
if (-not (Test-Path -LiteralPath $source)) { throw "Missing updater: $source" }
if (-not $SshAliases.Count -or @($SshAliases | Select-Object -Unique).Count -ne $SshAliases.Count) { throw 'Provide one or more distinct SSH aliases.' }
foreach ($alias in $SshAliases) { Assert-Alias $alias }
[void][IO.Directory]::CreateDirectory($reports)

if ($UndoLast) {
    if (-not (Test-Path -LiteralPath $latest)) { throw 'There is no saved change to undo in this updater folder.' }
    $saved = Get-Content -LiteralPath $latest -Raw | ConvertFrom-Json
    if ($saved.PSObject.Properties.Name -contains 'undone' -and $saved.undone) {
        Write-Host 'The last recorded change has already been undone.' -ForegroundColor Green
        return
    }
    $undoHosts = @($saved.hosts | Where-Object { $_.result.backup -and @($_.result.changed).Count -gt 0 })
    [array]::Reverse($undoHosts)
    foreach ($hostEntry in $undoHosts) {
        Assert-Alias ([string]$hostEntry.ssh_alias)
        $path = [string]$hostEntry.result.backup
        if ($path -notmatch '^/var/backups/whispr-utility-links/(\d{8}T\d{6}Z-[0-9a-f]{8})$') { throw 'Unexpected backup path in saved report.' }
        $backupId = $Matches[1]
        $restored = $null
        Invoke-HostUpdate -Alias $hostEntry.ssh_alias -Selected @() -OutputRecord ([ref]$restored) -BackupId $backupId
        Write-Host "Restored original page files on $($restored.ssh_alias)." -ForegroundColor Green
    }
    $saved | Add-Member -NotePropertyName undone -NotePropertyValue $true -Force
    Save-Run $saved $latest
    Write-Host 'Last utility-link update undone.' -ForegroundColor Green
    return
}

$pending = [Collections.Generic.List[string]]::new()
foreach ($domain in $domains) { $pending.Add($domain) }
$completed = [Collections.Generic.List[object]]::new()
$run = [pscustomobject]@{ version=1; run_id=$runId; mode=$(if ($Audit) { 'audit' } else { 'apply' }); hosts=@(); complete=$false; missing=@($domains); undone=$false }
foreach ($alias in $SshAliases) {
    if (-not $pending.Count) { break }
    $record = $null
    Invoke-HostUpdate -Alias $alias -Selected @($pending.ToArray()) -OutputRecord ([ref]$record)
    foreach ($domain in @($record.result.sites)) {
        if ($domain -notin $domains) { throw 'The server returned an unexpected domain.' }
        [void]$pending.Remove([string]$domain)
    }
    $completed.Add($record)
    $run.hosts = $completed.ToArray()
    $run.missing = $pending.ToArray()
    $run.complete = $pending.Count -eq 0
    Save-Run $run $runFile
    # A harmless rerun must not replace the most recent undoable change.
    if (-not $Audit -and @($completed | Where-Object { @($_.result.changed).Count -gt 0 }).Count -gt 0) {
        Save-Run $run $latest
    }
}
Write-Host "`nPer-host reports: $reports"
if ($pending.Count) {
    throw ('These sites were not found in their managed locations on the checked hosts: ' + ($pending -join ', ') + '. The report lists any sites already completed. You can rerun safely after installing the missing site, or supply -SshAliases with its actual host alias.')
}
foreach ($record in $completed) {
    foreach ($domain in @($record.result.sites)) { Write-Host ("{0}  ->  {1}" -f $domain,$record.ssh_alias) }
}
if ($Audit) { Write-Host "`nAudit passed for all six utilities. No page files changed." -ForegroundColor Green }
else { Write-Host "`nAll six utility homepages have five verified links to the other tools." -ForegroundColor Green }
