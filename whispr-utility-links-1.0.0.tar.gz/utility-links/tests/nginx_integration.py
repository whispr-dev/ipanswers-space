#!/usr/bin/env python3
"""Linux: python3 tests/nginx_integration.py /path/to/nginx /path/to/mime.types

Exercises six real TLS virtual hosts in a temporary prefix on loopback 8798.
No production configuration or system service is touched.
"""
import dataclasses
import importlib.util
import os
from pathlib import Path
import shutil
import ssl
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('utility_links_nginx',ROOT/'patch-links.py')
links=importlib.util.module_from_spec(spec);sys.modules[spec.name]=links;spec.loader.exec_module(links)

def run(binary,mime):
    with tempfile.TemporaryDirectory(prefix='utility-links-nginx-') as temporary:
        base=Path(temporary);base.chmod(0o755);(base/'logs').mkdir()
        cert=base/'cert.pem';key=base/'key.pem'
        names=','.join('DNS:'+site.domain for site in links.SITES)
        subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=utility-links-test','-addext','subjectAltName='+names,'-out',str(cert),'-keyout',str(key)],check=True,capture_output=True)
        sites=[];original={};hosts=[]
        for site in links.SITES:
            root=base/'sites'/site.domain;root.mkdir(parents=True)
            for name in ('index.html','style.css'):
                data=(ROOT/'tests/fixtures'/site.domain/name).read_bytes();(root/name).write_bytes(data);original[site.domain,name]=data
            sites.append(dataclasses.replace(site,root=root,cached_service=None))
            hosts.append(f'server {{ listen 127.0.0.1:8798 ssl; server_name {site.domain}; ssl_certificate {cert}; ssl_certificate_key {key}; root {root}; index index.html; location / {{ try_files $uri $uri/ =404; }} }}')
        config=('user root root;\n' if os.geteuid()==0 else '')+'daemon off;\nmaster_process off;\nevents {}\nhttp {\ninclude '+str(mime)+';\n'+'\n'.join(hosts)+'\n}\n'
        path=base/'nginx.conf';path.write_text(config)
        check=subprocess.run([str(binary),'-t','-p',str(base)+'/', '-c',str(path)],capture_output=True,text=True)
        if check.returncode:raise RuntimeError(check.stderr)
        process=subprocess.Popen([str(binary),'-p',str(base)+'/', '-c',str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        try:
            origin=links.Origin(ssl.create_default_context(cafile=str(cert)),8798)
            for attempt in range(30):
                try:origin.fetch(sites[0].domain,'/');break
                except OSError:time.sleep(.1)
            else:raise RuntimeError('Temporary Nginx did not start.')
            with patch.object(links,'SITES',tuple(sites)),patch.object(links,'BY_DOMAIN',{s.domain:s for s in sites}),patch.object(links,'BACKUPS',base/'backups'):
                result=links.apply(sites,origin)
                assert len(result['changed'])==6
                assert links.apply(sites,origin)['changed']==[]
                for site in sites:links.validate_links(origin.fetch(site.domain,'/'),site.domain)
                links.rollback(Path(result['backup']).name,origin)
                for site in sites:
                    assert origin.fetch(site.domain,'/')==original[site.domain,'index.html']
                    assert origin.fetch(site.domain,'/style.css')==original[site.domain,'style.css']
            try:origin.fetch('unlisted.example','/')
            except ssl.SSLCertVerificationError:pass
            else:raise AssertionError('TLS hostname verification must remain enabled.')
            print('PASS: real Nginx HTTPS, six SNI hosts, exact stylesheets, reciprocal links, idempotence, complete rollback, and rejection of an invalid TLS hostname.')
        finally:
            process.terminate();process.wait(timeout=5)

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit(__doc__)
    run(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve())
