#requires -Version 7.0
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$project = Split-Path -Parent $PSScriptRoot
$all = @('fastping.it.com','dailystonks.org','ipanswers.space','isitmeornot.online','mdconv.site','whatdoesmyscreen.fit')

function Assert([bool]$Condition,[string]$Message) { if (-not $Condition) { throw $Message } }
function global:ssh {
    $values = @($args | ForEach-Object { [string]$_ })
    $command = $values[-1]
    $alias = @($values | Where-Object { $_ -in @('lon1','nyc1') })[0]
    $global:UtilityFixture.calls.Add([pscustomobject]@{ alias=$alias; command=$command; arguments=$values })
    $global:LASTEXITCODE = 0
    if ($command -notmatch '^sudo -- python3 ') { return }
    if ($values -notcontains '-t') { throw 'Sudo must retain its interactive terminal.' }
    if ($command -match "--rollback '([^']+)'") {
        $mode = 'rollback'; $sites = @($global:UtilityFixture.available[$alias]); $changed = $sites
    } else {
        if ($command -notmatch "--sites '([^']+)'") { throw 'Missing domain selection.' }
        $selection = $Matches[1] -split ','
        $sites = @($selection | Where-Object { $_ -in $global:UtilityFixture.available[$alias] })
        $mode = if ($command -match ' --audit') { 'audit' } else { 'apply' }
        $changed = if ($mode -eq 'audit' -or $global:UtilityFixture.noChanges) { @() } else { $sites }
    }
    $backup = if (@($changed).Count) { '/var/backups/whispr-utility-links/20261025T180000Z-' + $(if ($alias -eq 'lon1') {'aabbccdd'} else {'11223344'}) } else { $null }
    $result = [ordered]@{ ok=$true; mode=$mode; sites=@($sites); changed=@($changed); missing=@(); backup=$backup }
    if ($global:UtilityFixture.failAlias -eq $alias) {
        $result.ok=$false; $result.sites=@(); $result.changed=@(); $result['error']='injected server failure'; $global:LASTEXITCODE=1
    }
    $global:UtilityFixture.results[$alias] = $result
    Write-Output 'Fixture server progress: this output must not contaminate the returned record.'
}
function global:scp {
    $values = @($args | ForEach-Object { [string]$_ })
    $source = @($values | Where-Object { $_ -match '^(lon1|nyc1):/tmp/.+/report.json$' })
    if ($source.Count) {
        $alias = ($source[0] -split ':')[0]
        $global:UtilityFixture.results[$alias] | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $values[-1] -Encoding utf8
    }
    $global:LASTEXITCODE=0
}
function Fixture([scriptblock]$Body) {
    $temporary = Join-Path ([IO.Path]::GetTempPath()) ('utility-runner-test-' + [guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($temporary)
    Copy-Item -LiteralPath (Join-Path $project 'Update-UtilityLinks.ps1') -Destination $temporary
    Copy-Item -LiteralPath (Join-Path $project 'patch-links.py') -Destination $temporary
    $global:UtilityFixture = @{
        available=@{lon1=@('ipanswers.space','isitmeornot.online','mdconv.site','whatdoesmyscreen.fit');nyc1=@('fastping.it.com','dailystonks.org')}
        calls=[Collections.Generic.List[object]]::new(); results=@{}; noChanges=$false; failAlias=''
    }
    try { & $Body (Join-Path $temporary 'Update-UtilityLinks.ps1') $temporary }
    finally { Remove-Item -LiteralPath $temporary -Recurse -Force }
}

try {
    $parseErrors=$null;$tokens=$null
    [void][Management.Automation.Language.Parser]::ParseFile((Join-Path $project 'Update-UtilityLinks.ps1'),[ref]$tokens,[ref]$parseErrors)
    Assert (@($parseErrors).Count -eq 0) 'PowerShell syntax errors found.'

    Fixture {
        param($script,$folder)
        & $script
        $record=Get-Content -Raw (Join-Path $folder 'reports/latest-change.json') | ConvertFrom-Json
        Assert $record.complete 'Two-host run must complete all six.'
        Assert (@($record.hosts).Count -eq 2) 'Both hosts must be recorded.'
        Assert (@($record.hosts[0].result.sites).Count -eq 4) 'London must contain four utilities.'
        Assert (@($record.hosts[1].result.sites).Count -eq 2) 'NYC must receive only the remaining two.'
        $latestHash=(Get-FileHash (Join-Path $folder 'reports/latest-change.json')).Hash
        $global:UtilityFixture.noChanges=$true
        & $script
        Assert ((Get-FileHash (Join-Path $folder 'reports/latest-change.json')).Hash -eq $latestHash) 'No-op rerun must retain the last undoable update.'
        & $script -UndoLast
        $record=Get-Content -Raw (Join-Path $folder 'reports/latest-change.json') | ConvertFrom-Json
        Assert $record.undone 'Undo must be recorded.'
        $rollbacks=@($global:UtilityFixture.calls | Where-Object { $_.command -match '--rollback' })
        Assert ($rollbacks.Count -eq 2) 'Undo must restore both changed hosts.'
        Assert ($rollbacks[0].alias -eq 'nyc1') 'Undo must run in reverse host order.'
    }
    'PASS: two-host application, visible SSH output, no-op rerun, persistent undo and reverse-order rollback.'

    Fixture {
        param($script,$folder)
        $global:UtilityFixture.available.lon1=$all
        & $script
        Assert (@($global:UtilityFixture.calls | Where-Object { $_.alias -eq 'nyc1' }).Count -eq 0) 'When all six are on lon1, nyc1 must not be contacted.'
    }
    'PASS: one-host installation stops after finding all six.'

    Fixture {
        param($script,$folder)
        & $script -Audit
        Assert (-not (Test-Path (Join-Path $folder 'reports/latest-change.json'))) 'Audit must not create an undo record.'
        Assert (@($global:UtilityFixture.results.lon1.changed).Count -eq 0) 'Audit must report no changed pages.'
    }
    'PASS: audit has no page changes and preserves undo history.'

    Fixture {
        param($script,$folder)
        $global:UtilityFixture.failAlias='nyc1'
        $failed=$false
        try { & $script } catch { $failed=$true; Assert ($_.Exception.Message -match 'injected server failure') 'Actual server error must be retained.' }
        Assert $failed 'Server failure must not be reported as success.'
        $record=Get-Content -Raw (Join-Path $folder 'reports/latest-change.json') | ConvertFrom-Json
        Assert (-not $record.complete) 'Partial completion must remain explicit.'
        Assert (@($record.hosts).Count -eq 1) 'Completed London changes must remain undoable.'
    }
    'PASS: later-host failure preserves a truthful, undoable partial result.'

    Fixture {
        param($script,$folder)
        $global:UtilityFixture.available.nyc1=@()
        $failed=$false
        try { & $script } catch { $failed=$true; Assert ($_.Exception.Message -match 'not found') 'Missing sites must be listed.' }
        Assert $failed 'Missing utilities must not be reported as complete.'
    }
    'PASS: missing utility sites fail with an explicit report.'
} finally {
    Remove-Item Function:\ssh,Function:\scp -ErrorAction SilentlyContinue
    Remove-Variable UtilityFixture -Scope Global -ErrorAction SilentlyContinue
}
