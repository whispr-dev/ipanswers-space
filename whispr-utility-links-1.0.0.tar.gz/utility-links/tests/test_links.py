import dataclasses
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('utility_links',ROOT/'patch-links.py')
links=importlib.util.module_from_spec(spec);sys.modules[spec.name]=links;spec.loader.exec_module(links)


class TransformTests(unittest.TestCase):
    def test_all_six_real_homepages_get_exactly_the_other_five_links(self):
        for site in links.SITES:
            with self.subTest(domain=site.domain):
                root=ROOT/'tests/fixtures'/site.domain
                html=(root/'index.html').read_bytes();css=(root/'style.css').read_bytes()
                changed=links.patch_html(html,site.domain);changed_css=links.patch_css(css)
                links.validate_links(changed,site.domain)
                block=changed.decode().split(links.HTML_BEGIN)[1].split(links.HTML_END)[0]
                self.assertNotIn('href="https://'+site.domain+'/',block)
                self.assertNotIn('msconv.site',block)
                self.assertEqual(changed,links.patch_html(changed,site.domain))
                self.assertEqual(changed_css,links.patch_css(changed_css))
                self.assertEqual(changed.decode().replace(links.link_block(site.domain)+'\n','',1),html.decode())
                self.assertTrue(changed_css.startswith(css))
                self.assertEqual(changed_css.count(links.CSS_BEGIN.encode()),1)
                self.assertIn('whispr.dev</a>’s other utility sites',block)

    def test_template_tokens_and_scripts_remain_byte_identical(self):
        html=(ROOT/'tests/fixtures/ipanswers.space/index.html').read_bytes()
        changed=links.patch_html(html,'ipanswers.space')
        for token in (b'@@IP@@',b'@@UA@@',b'@@LOCATION@@'):
            self.assertEqual(changed.count(token),html.count(token))
        self.assertIn(b'<script src="/app.js"',changed)

    def test_real_tag_offsets_ignore_closing_strings_in_scripts(self):
        original=b'<html><head><link rel="stylesheet" href="/style.css"></head><body><script>const s="</body><footer>";</script><footer>real</footer></body></html>'
        updated=links.patch_html(original,'mdconv.site').decode()
        self.assertIn('<script>const s="</body><footer>";</script>',updated)
        self.assertLess(updated.index(links.HTML_BEGIN),updated.index('<footer>real'))

    def test_crlf_and_bom_are_preserved(self):
        html='\ufeff<html>\r\n<head><link rel="stylesheet" href="/style.css"></head>\r\n<body><footer>original</footer></body></html>\r\n'.encode()
        updated=links.patch_html(html,'mdconv.site')
        self.assertTrue(updated.startswith(b'\xef\xbb\xbf'))
        self.assertNotIn(b'\n',updated.replace(b'\r\n',b''))
        self.assertEqual(updated,links.patch_html(updated,'mdconv.site'))

    def test_incomplete_markers_and_ambiguous_documents_are_rejected(self):
        html=(ROOT/'tests/fixtures/mdconv.site/index.html').read_bytes()
        for broken in (html.replace(b'</body>',links.HTML_BEGIN.encode()+b'</body>'),html.replace(b'</body>',b''),html.replace(b'</body>',b'<footer>extra</footer></body>'),html.replace(b'/style.css',b'/different.css')):
            with self.subTest():
                with self.assertRaises(ValueError):links.patch_html(broken,'mdconv.site')
        with self.assertRaises(ValueError):links.patch_css(b'body{}\n'+links.CSS_BEGIN.encode())


class FakeOrigin:
    def __init__(self,sites):
        self.sites={site.domain:site for site in sites};self.cached={};self.restarts=[];self.fail_after_write=False
        for site in sites:
            if site.cached_service:self.refresh(site)
    def refresh(self,site):
        self.cached[site.domain]={path:(site.root/name).read_bytes() for path,name in [('/','index.html'),('/style.css','style.css')]}
    def fetch(self,domain,path):
        site=self.sites[domain]
        data=self.cached[domain][path] if domain in self.cached else (site.root/('index.html' if path=='/' else 'style.css')).read_bytes()
        if self.fail_after_write and links.HTML_BEGIN.encode() in data:raise RuntimeError('injected origin verification failure')
        return data
    def restart(self,name):
        self.restarts.append(name)
        for site in self.sites.values():
            if site.cached_service==name:self.refresh(site)


class TransactionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
        self.sites=[]
        for site in links.SITES:
            root=self.base/'sites'/site.domain;root.mkdir(parents=True)
            for name in ['index.html','style.css']:(root/name).write_bytes((ROOT/'tests/fixtures'/site.domain/name).read_bytes())
            self.sites.append(dataclasses.replace(site,root=root))
        self.patches=[patch.object(links,'SITES',tuple(self.sites)),patch.object(links,'BY_DOMAIN',{s.domain:s for s in self.sites}),patch.object(links,'BACKUPS',self.base/'backups'),patch.object(links,'validate_cached_service'),patch.object(links.time,'sleep')]
        for p in self.patches:p.start()
        self.origin=FakeOrigin(self.sites)
        self.original={(site.domain,name):(site.root/name).read_bytes() for site in self.sites for name in ['index.html','style.css']}
    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.temp.cleanup()
    def assert_original(self):
        for site in self.sites:
            for name in ['index.html','style.css']:self.assertEqual((site.root/name).read_bytes(),self.original[site.domain,name])

    def test_apply_verify_idempotence_and_undo_with_cached_services(self):
        neighbor=self.base/'litehaus.conf';neighbor.write_text('keep me')
        with patch.object(links,'restart_service',side_effect=self.origin.restart):
            result=links.apply(self.sites,self.origin)
            self.assertEqual(set(result['changed']),set(s.domain for s in self.sites))
            self.assertEqual(sorted(self.origin.restarts),['ipanswers.service','isitmeornot.service'])
            for site in self.sites:links.validate_links(self.origin.fetch(site.domain,'/'),site.domain)
            again=links.apply(self.sites,self.origin)
            self.assertEqual(again['changed'],[]);self.assertIsNone(again['backup'])
            self.assertEqual(len(self.origin.restarts),2)
            restored=links.rollback(Path(result['backup']).name,self.origin)
            self.assertTrue(restored['ok']);self.assert_original()
            links.rollback(Path(result['backup']).name,self.origin) # Already-original files are safe.
        self.assertEqual(neighbor.read_text(),'keep me')

    def test_audit_changes_no_page_or_backup(self):
        result=links.apply(self.sites,self.origin,audit=True)
        self.assertEqual(len(result['sites']),6);self.assertEqual(result['changed'],[])
        self.assertFalse((self.base/'backups').exists());self.assert_original()

    def test_post_write_failure_restores_all_files_and_caches(self):
        self.origin.fail_after_write=True
        with patch.object(links,'restart_service',side_effect=self.origin.restart):
            with self.assertRaisesRegex(RuntimeError,'Original page files restored'):
                links.apply(self.sites,self.origin)
        self.assert_original()
        self.assertEqual(self.origin.restarts.count('ipanswers.service'),2)
        for site in self.sites:self.assertNotIn(links.HTML_BEGIN.encode(),self.origin.fetch(site.domain,'/'))

    def test_write_failure_restores_completed_earlier_files(self):
        real=links.atomic
        def broken(path,data,*args):
            if path.name=='index.html' and path.parent.name=='dailystonks.org' and links.HTML_BEGIN.encode() in data:
                raise OSError('injected disk failure')
            return real(path,data,*args)
        with patch.object(links,'atomic',side_effect=broken),patch.object(links,'restart_service',side_effect=self.origin.restart):
            with self.assertRaisesRegex(RuntimeError,'disk failure'):links.apply(self.sites,self.origin)
        self.assert_original()

    def test_unmatched_origin_and_missing_roots_are_not_patched(self):
        original=self.origin.fetch
        def wrong(domain,path):return b'wrong origin' if domain==self.sites[0].domain and path=='/style.css' else original(domain,path)
        with patch.object(self.origin,'fetch',side_effect=wrong):
            with self.assertRaisesRegex(RuntimeError,'differs'):links.apply(self.sites,self.origin)
        self.assert_original()
        missing=dataclasses.replace(self.sites[0],root=self.base/'not-installed')
        result=links.apply([missing],self.origin)
        self.assertEqual(result['sites'],[]);self.assertEqual(result['missing'],[missing.domain])

    def test_manual_rollback_will_not_overwrite_later_edits(self):
        with patch.object(links,'restart_service',side_effect=self.origin.restart):
            result=links.apply(self.sites,self.origin)
            changed=self.sites[-1].root/'style.css';changed.write_bytes(changed.read_bytes()+b'/* later owner edit */')
            before={path:path.read_bytes() for site in self.sites for path in site.root.iterdir()}
            with self.assertRaisesRegex(ValueError,'edited after'):links.rollback(Path(result['backup']).name,self.origin)
        for path,data in before.items():self.assertEqual(path.read_bytes(),data)

    def test_manual_rollback_refuses_changed_release(self):
        with patch.object(links,'restart_service',side_effect=self.origin.restart):result=links.apply(self.sites,self.origin)
        site=self.sites[0];old=site.root;replacement=old.with_name(old.name+'-new');old.rename(replacement);old.symlink_to(replacement)
        with self.assertRaisesRegex(ValueError,'active release changed'):links.rollback(Path(result['backup']).name,self.origin)


if __name__=='__main__':unittest.main()
